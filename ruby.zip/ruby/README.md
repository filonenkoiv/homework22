# Danylo Sydorenko CS-34

Library App

## HTTP Verbs

| HTTP METHOD | URL                    | Payload                                                                                                                                                                             | Description                                 |
|-------------|------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------|
| GET         | /authors               | {}                                                                                                                                                                                  | Shows the whole author table.               |
| POST        | /authors               | {name: 'Danylo', address: 'idk', book_id: 3, created_at: '', updated_at: ''}                                                                                                        | Creates new author.                         |
| GET         | /authors/new           | {}                                                                                                                                                                                  | Returns created author.                     |
| GET         | /authors/:id/edit      | {id: 2}                                                                                                                                                                             | Edits the specific author by id.            |
| GET         | /authors/:id           | {id: 2}                                                                                                                                                                             | Shows the specific author table by id.      |
| PATCH       | /authors/:id           | {id: 2}                                                                                                                                                                             | Returns the edited author.                  |
| PUT         | /authors/:id           | {id: 2}                                                                                                                                                                             | Updates authors.                            |
| DELETE      | /authors/:id           | {id: 2}                                                                                                                                                                             | Deletes the specified author.               |
| GET         | /books                 | {}                                                                                                                                                                                  | Shows the whole book table.                 |
| POST        | /books                 | {name: 'BookName', description: 'BookDesc',  library_id: 1, created_at: '', updated_at: ''}                                                                                         | Creates new book.                           |
| GET         | /books/new             | {}                                                                                                                                                                                  | Returns created book.                       |
| GET         | /books/:id/edit        | {id: 4}                                                                                                                                                                             | Edits the specific book by id.              |
| GET         | /books/:id             | {id: 4}                                                                                                                                                                             | Shows the specific book table by id.        |
| PATCH       | /books/:id             | {id: 4}                                                                                                                                                                             | Returns the edited book.                    |
| PUT         | /books/:id             | {id: 4}                                                                                                                                                                             | Updates books.                              |
| DELETE      | /books/:id             | {id: 4}                                                                                                                                                                             | Deletes the specified book.                 |
| GET         | /libraries             | {}                                                                                                                                                                                  | Shows the whole library table.              |
| POST        | /libraries             | {name: 'Misha', owner: 'Hessv', address: 'str. Heroyiv', created_at: '', updated_at: ''}                                                                                            | Creates new library.                        |
| GET         | /libraries/new         | {}                                                                                                                                                                                  | Returns created library.                    |
| GET         | /libraries/:id/edit    | {id: 3}                                                                                                                                                                             | Edits the specific library by id.           |
| GET         | /libraries/:id         | {id: 3}                                                                                                                                                                             | Shows the specific library table by id.     |
| PATCH       | /libraries/:id         | {id: 3}                                                                                                                                                                             | Returns the edited library.                 |
| PUT         | /libraries/:id         | {id: 3}                                                                                                                                                                             | Updates libraries.                          |
| DELETE      | /libraries/:id         | {id: 3}                                                                                                                                                                             | Deletes the specified library.              |
| GET         | /genres                | {}                                                                                                                                                                                  | Shows the whole genre table.                |
| POST        | /genres                | { id: 1, name: 'alarm', book_id: 94, created_at: '1992-08-21 15:24:00 +0300', updated_at: '1992-08-21 15:24:00 +0300' }                                                             | Creates new genre.                          |
| GET         | /genres/new            | {}                                                                                                                                                                                  | Returns created genre.                      |
| GET         | /genres/:id/edit       | {id: 2}                                                                                                                                                                             | Edits the specific genre by id.             |
| GET         | /genres/:id            | {id: 2}                                                                                                                                                                             | Shows the specific genre table by id.       |
| PATCH       | /genres/:id            | {id: 2}                                                                                                                                                                             | Returns the edited genre.                   |
| PUT         | /genres/:id            | {id: 2}                                                                                                                                                                             | Updates genres.                             |
| DELETE      | /genres/:id            | {id: 2}                                                                                                                                                                             | Deletes the specified genre.                |
| GET         | /card_readers          | {}                                                                                                                                                                                  | Shows the whole card_reader table.          |
| POST        | /card_readers          | { id: 1, count: 127, last_book: 'Practice Alarm', library_id: 33, created_at: '2008-02-21 10:52:33 +0200', updated_at: '2008-02-21 10:52:33 +0200' }                                | Creates new card_reader.                    |
| GET         | /card_readers/new      | {}                                                                                                                                                                                  | Returns created card_reader.                |
| GET         | /card_readers/:id/edit | {id: 2}                                                                                                                                                                             | Edits the specific card_reader by id.       |
| GET         | /card_readers/:id      | {id: 2}                                                                                                                                                                             | Shows the specific card_reader table by id. |
| PATCH       | /card_readers/:id      | {id: 2}                                                                                                                                                                             | Returns the edited card_reader.             |
| PUT         | /card_readers/:id      | {id: 2}                                                                                                                                                                             | Updates card_readers.                       |
| DELETE      | /card_readers/:id      | {id: 2}                                                                                                                                                                             | Deletes the specified card_reader.          |
| GET         | /users                 | {}                                                                                                                                                                                  | Shows the whole user table.                 |
| POST        | /users                 | { id: 1, name: 'Анастасія', surname: 'Станішевський', patronym: 'Русланович', card_reader_id: 1, created_at: '2004-02-06 22:46:36 +0200', updated_at: '2004-02-06 22:46:36 +0200' } | Creates new user.                           |
| GET         | /users/new             | {}                                                                                                                                                                                  | Returns created user.                       |
| GET         | /users/:id/edit        | {id: 2}                                                                                                                                                                             | Edits the specific user by id.              |
| GET         | /users/:id             | {id: 2}                                                                                                                                                                             | Shows the specific user table by id.        |
| PATCH       | /users/:id             | {id: 2}                                                                                                                                                                             | Returns the edited user.                    |
| PUT         | /users/:id             | {id: 2}                                                                                                                                                                             | Updates users.                              |
| DELETE      | /users/:id             | {id: 2}                                                                                                                                                                             | Deletes the specified user.                 |

## ERD diagram

<img src="err_digram.jpg" alt="ERD Digram" width="600" height="500">

### Labs

- [] Task 1 -> Вставити 100 записів у ваші таблиці. У кожній групі по 6 таблиць в 3 таблиці зробити методи, які будуть
  обгорткою на чистому SQL. У 3 таблиці просто на ОРМ.
  У кожній моделі повинні бути методи на оновлення. В 3 таблиці зробити методи, які будуть обгорткою на чистому SQL. У 3
  таблиці просто на ОРМ.
  Зробити по 2 SQL VIEW.
- [] Task 2 -> Зробити CRUD форми под кожну модель

