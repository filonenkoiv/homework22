require "test_helper"

class BookTest < ActiveSupport::TestCase

end
