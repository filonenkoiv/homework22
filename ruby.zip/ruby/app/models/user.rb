class User < ApplicationRecord
  belongs_to :card_reader
end
