class Author < ApplicationRecord
  belongs_to :book
end
