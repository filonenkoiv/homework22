class Genre < ApplicationRecord
  belongs_to :book
end
