class Book < ApplicationRecord
  belongs_to :library
end
