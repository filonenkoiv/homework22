# Supported types for database columns:

<ul>
    <li>binary</li>
    <li>boolean </li>
    <li>date </li>
    <li>datetime</li>
    <li>decimal</li>
    <li>float </li>
    <li>integer </li>
    <li>primary_key</li>
    <li>string </li><li>text</li>
    <li>time</li>
    <li>timestamp</li>
</ul>